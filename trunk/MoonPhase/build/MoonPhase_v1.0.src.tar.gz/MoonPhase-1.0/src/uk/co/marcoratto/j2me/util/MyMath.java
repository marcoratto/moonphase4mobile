package uk.co.marcoratto.j2me.util;

public class MyMath {

	public static double round(double d) {
		return Math.floor(d + 0.5d);
	}
}
